package com.example.women_safety

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
